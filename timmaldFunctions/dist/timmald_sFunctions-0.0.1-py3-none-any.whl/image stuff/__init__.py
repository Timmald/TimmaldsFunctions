import randShift
